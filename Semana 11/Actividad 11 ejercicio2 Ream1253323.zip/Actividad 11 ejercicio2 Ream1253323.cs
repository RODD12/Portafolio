﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Act_11_Ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2");

            int numeroDia;

            try
            {
                Console.Write("Ingrese el número de día (1-7): ");
                string input = Console.ReadLine();
                numeroDia = Convert.ToInt32(input);

                if (numeroDia < 1 || numeroDia > 7)
                {
                    Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
                    return;
                }

                string dia;

                if (numeroDia == 1)
                {
                    dia = "lunes";
                }
                else if (numeroDia == 2)
                {
                    dia = "martes";
                }
                else if (numeroDia == 3)
                {
                    dia = "miércoles";
                }
                else if (numeroDia == 4)
                {
                    dia = "jueves";
                }
                else if (numeroDia == 5)
                {
                    dia = "viernes";
                }
                else if (numeroDia == 6)
                {
                    dia = "sábado";
                }
                else
                {
                    dia = "domingo";
                }

                Console.WriteLine("DIA: " + dia);
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: Ingresa un número válido.");
                
            }
            Console.ReadLine(); 
        }
    }
}
    

