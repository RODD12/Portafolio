﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actividad_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");

            int numero;

            try
            {
                Console.Write("Número ENTERO: ");
                string input = Console.ReadLine();
                numero = Convert.ToInt32(input);
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: Ingresa un número entero válido.");
                return;
            }

            string resultado;

            if (numero > 0)
            {
                resultado = "positivo";
            }
            else if (numero < 0)
            {
                resultado = "negativo";
            }
            else
            {
                resultado = "cero";
            }

            Console.WriteLine("RESULTADO: El número es " + resultado);
            Console.ReadLine();
        }
    }
}
    

